/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.lmf;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static wiremock.org.apache.commons.lang3.StringUtils.EMPTY;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import com.lmf.api.intern.cards.CardApi;
import com.lmf.api.intern.cards.CardsRequest;
import com.lmf.api.intern.cards.CardsResponse;
import com.lmf.api.intern.clans.ClanApi;
import com.lmf.api.intern.clans.ClansRequest;
import com.lmf.api.intern.clans.ClansResponse;
import com.lmf.api.intern.clans.info.ClanRequest;
import com.lmf.api.intern.clans.info.ClanResponse;
import com.lmf.api.intern.clans.members.ClanMembersRequest;
import com.lmf.api.intern.clans.members.ClanMembersResponse;
import com.lmf.api.intern.clans.riverracelog.RiverRaceLogRequest;
import com.lmf.api.intern.locations.LocationApi;
import com.lmf.api.intern.locations.LocationsRequest;
import com.lmf.api.intern.locations.LocationsResponse;
import com.lmf.api.intern.locations.info.LocationRequest;
import com.lmf.api.intern.locations.info.LocationResponse;
import com.lmf.api.intern.locations.seasons.global.rankings.TopPlayerLeagueSeasonRankingsResponse;
import com.lmf.api.intern.players.upcomingchests.UpcomingChestsRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.StringReader;
import javax.json.Json;
import javax.json.JsonPatch;
import javax.json.JsonValue;

import com.lmf.api.intern.challenges.ChallengeApi;
import com.lmf.api.intern.challenges.ChallengesRequest;
import com.lmf.api.intern.challenges.ChallengesResponse;
import com.lmf.api.intern.clans.currentriverrace.CurrentRiverRaceRequest;
import com.lmf.api.intern.clans.currentriverrace.CurrentRiverRaceResponse;
import com.lmf.api.intern.clans.riverracelog.RiverRaceLogResponse;
import com.lmf.api.intern.globaltournaments.GlobalTournamentApi;
import com.lmf.api.intern.globaltournaments.GlobalTournamentsRequest;
import com.lmf.api.intern.globaltournaments.GlobalTournamentsResponse;
import com.lmf.api.intern.locations.rankings.clan.ClanRankingsRequest;
import com.lmf.api.intern.locations.rankings.clan.ClanRankingsResponse;
import com.lmf.api.intern.locations.rankings.clanwar.ClanWarRankingsRequest;
import com.lmf.api.intern.locations.rankings.clanwar.ClanWarRankingsResponse;
import com.lmf.api.intern.locations.rankings.player.PlayerRankingsRequest;
import com.lmf.api.intern.locations.rankings.player.PlayerRankingsResponse;
import com.lmf.api.intern.locations.seasons.global.TopPlayerLeagueSeasonsRequest;
import com.lmf.api.intern.locations.seasons.global.TopPlayerLeagueSeasonsResponse;
import com.lmf.api.intern.locations.seasons.global.info.TopPlayerLeagueSeasonRequest;
import com.lmf.api.intern.locations.seasons.global.info.TopPlayerLeagueSeasonResponse;
import com.lmf.api.intern.locations.seasons.global.rankings.TopPlayerLeagueSeasonRankingsRequest;
import com.lmf.api.intern.players.PlayerApi;
import com.lmf.api.intern.players.battlelog.BattleLogRequest;
import com.lmf.api.intern.players.battlelog.BattleLogResponse;
import com.lmf.api.intern.players.info.PlayerRequest;
import com.lmf.api.intern.players.info.PlayerResponse;
import com.lmf.api.intern.players.upcomingchests.UpcomingChestsResponse;
import com.lmf.api.intern.tournament.TournamentApi;
import com.lmf.api.intern.tournaments.TournamentsRequest;
import com.lmf.api.intern.tournaments.TournamentsResponse;
import com.lmf.api.intern.tournaments.info.TournamentRequest;
import com.lmf.api.intern.tournaments.info.TournamentResponse;
import com.lmf.connector.StandardConnector;

public class EndToEnd {

  private static final Gson GSON = new GsonBuilder().disableHtmlEscaping().create();

  private CRApiConnector CRApiConnector;

  private ClanApi clanApi;

  private PlayerApi playerApi;

  private CardApi cardApi;

  private TournamentApi tournamentApi;

  private LocationApi locationApi;

  private ChallengeApi challengeApi;

  private GlobalTournamentApi globalTournamentApi;

  @BeforeEach
  void setUp() {
    CRApiConnector =
        new CRApiConnector("https://proxy.royaleapi.dev/v1", System.getProperty("apiKey", System.getenv("API_KEY")),
            new StandardConnector());
    clanApi = CRApiConnector.getApi(ClanApi.class);
    playerApi = CRApiConnector.getApi(PlayerApi.class);
    cardApi = CRApiConnector.getApi(CardApi.class);
    tournamentApi = CRApiConnector.getApi(TournamentApi.class);
    locationApi = CRApiConnector.getApi(LocationApi.class);
    challengeApi = CRApiConnector.getApi(ChallengeApi.class);
    globalTournamentApi = CRApiConnector.getApi(GlobalTournamentApi.class);
  }

  private void assertDiff(String expected, String actual) {
    JsonValue source = Json.createReader(new StringReader(actual)).readValue();
    JsonValue target = Json.createReader(new StringReader(expected)).readValue();
    JsonPatch diff;
    try {
      diff = Json.createDiff(source.asJsonObject(), target.asJsonObject());
    } catch (ClassCastException e) {
      diff = Json.createDiff(source.asJsonArray(), target.asJsonArray());
    }
    StringBuilder diffOutput = new StringBuilder();
    diff.toJsonArray().forEach(entry -> diffOutput.append(entry + "\n"));
    assertEquals(EMPTY, diffOutput.toString());
  }

  @Test
  void clans_findAll() throws Exception {
    ClansResponse
        clansResponse =
        clanApi.findAll(ClansRequest.builder()
            .name("puz")
            .locationId(57000120)
            .minMembers(5)
            .maxMembers(20)
            .storeRawResponse(true).build()).get();
    String actual = GSON.toJson(clansResponse);
    String expected = clansResponse.getRawResponse().getRaw();

    assertDiff(expected, actual);
  }

  @Test
  void clans_findByTag() throws Exception {
    ClanResponse
        response =
        clanApi.findByTag(ClanRequest.builder("#RP88QQG").storeRawResponse(true).build()).get();
    String actual = GSON.toJson(response);
    String expected = response.getRawResponse().getRaw();

    assertDiff(expected, actual);
  }

  @Test
  void clans_getRiverRaceLog() throws Exception {
    RiverRaceLogResponse
        response =
        clanApi.getRiverRaceLog(RiverRaceLogRequest.builder("#RP88QQG").storeRawResponse(true).build()).get();
    String actual = GSON.toJson(response);
    String expected = response.getRawResponse().getRaw();

    assertDiff(expected, actual);
  }

  @Test
  void clans_getMembers() throws Exception {
    ClanMembersResponse
        response =
        clanApi.getMembers(ClanMembersRequest.builder("#RP88QQG").storeRawResponse(true).build()).get();
    String actual = GSON.toJson(response);
    String expected = response.getRawResponse().getRaw();

    assertDiff(expected, actual);
  }

  @Test
  void clans_getCurrentRiverRaceLog() throws Exception {
    CurrentRiverRaceResponse
        response =
        clanApi.getCurrentRiverRace(CurrentRiverRaceRequest.builder("#RP88QQG").storeRawResponse(true).build()).get();
    String actual = GSON.toJson(response);
    String expected = response.getRawResponse().getRaw();

    assertDiff(expected, actual);
  }

  @Test
  void players_findByTag() throws Exception {
    PlayerResponse
        response =
        playerApi.findByTag(PlayerRequest.builder("#2PGGCJJL").storeRawResponse(true).build()).get();
    String actual = GSON.toJson(response)
        .replace(",\"starLevel\":0", "")
        .replace(",\"target\":0", "");
    String expected = response.getRawResponse().getRaw().replace(",\"completionInfo\":null", "");

    assertDiff(expected, actual);
  }

  @Test
  void players_getUpcomingChests() throws Exception {
    UpcomingChestsResponse
        response =
        playerApi.getUpcomingChests(UpcomingChestsRequest.builder("#2PGGCJJL").storeRawResponse(true).build()).get();
    String actual = GSON.toJson(response);
    String expected = response.getRawResponse().getRaw();

    assertDiff(expected, actual);
  }

  @Test
  void players_getBattleLog() throws Exception {
    BattleLogResponse
        response =
        playerApi.getBattleLog(BattleLogRequest.builder("#2PGGCJJL").storeRawResponse(true).build()).get();
    String actual = GSON.toJson(response)
        .replace(",\"startingTrophies\":0", "")
        .replace(",\"crowns\":0", "")
        .replace(",\"trophyChange\":0", "")
        .replace(",\"kingTowerHitPoints\":0", "")
        .replace(",\"boatBattleWon\":false", "")
        .replace(",\"newTowersDestroyed\":0", "")
        .replace(",\"prevTowersDestroyed\":0", "")
        .replace(",\"prevTowersDestroyedprevTowersDestroyed\":0", "")
        .replace(",\"remainingTowers\":0", "")
        .replace(",\"starLevel\":0", "");
    String expected = response.getRawResponse().getRaw()
        .replace(",\"crowns\":0", "")
        .replace(",\"boatBattleWon\":false", "")
        .replace(",\"remainingTowers\":0", "")
        .replace(",\"prevTowersDestroyed\":0", "")
        .replace(",\"newTowersDestroyed\":0", "");

    assertDiff(expected, actual);
  }

  @Test
  void cards_findAll() throws Exception {
    CardsResponse
        response =
        cardApi.findAll(CardsRequest.builder().storeRawResponse(true).build()).get();
    String actual = GSON.toJson(response);
    String expected = response.getRawResponse().getRaw();

    assertDiff(expected, actual);
  }

  @Test
  void tournaments_findAll() throws Exception {
    TournamentsResponse
        response =
        tournamentApi.findAll(TournamentsRequest.builder().name("de").storeRawResponse(true).build()).get();
    String actual = GSON.toJson(response);
    String expected = response.getRawResponse().getRaw();

    assertDiff(expected, actual);
  }

  @Test
  void tournaments_findByTag() throws Exception {
    TournamentResponse
        response =
        tournamentApi.findByTag(TournamentRequest.builder("#U2QQQL2").storeRawResponse(true).build()).get();
    String actual = GSON.toJson(response);
    String expected = response.getRawResponse().getRaw();

    assertDiff(expected, actual);
  }

  @Test
  void locations_findAll() throws Exception {
    LocationsResponse
        response =
        locationApi.findAll(LocationsRequest.builder().storeRawResponse(true).build()).get();
    String actual = GSON.toJson(response);
    String expected = response.getRawResponse().getRaw();

    assertDiff(expected, actual);
  }

  @Test
  void locations_findById() throws Exception {
    LocationResponse
        response =
        locationApi.findById(LocationRequest.builder(57000256L).storeRawResponse(true).build()).get();
    String actual = GSON.toJson(response);
    String expected = response.getRawResponse().getRaw();

    assertDiff(expected, actual);
  }

  @Test
  void locations_getClanRankings() throws Exception {
    ClanRankingsResponse
        response =
        locationApi.getClanRankings(ClanRankingsRequest.builder(57000256L).storeRawResponse(true).build()).get();
    String actual = GSON.toJson(response);
    String expected = response.getRawResponse().getRaw();

    assertDiff(expected, actual);
  }

  @Test
  void locations_getPlayerRankings() throws Exception {
    PlayerRankingsResponse
        response =
        locationApi.getPlayerRankings(PlayerRankingsRequest.builder(57000256L).storeRawResponse(true).build()).get();
    String actual = GSON.toJson(response);
    String expected = response.getRawResponse().getRaw();

    assertDiff(expected, actual);
  }

  @Test
  void locations_getClanWarRankings() throws Exception {
    ClanWarRankingsResponse
        response =
        locationApi.getClanWarRankings(ClanWarRankingsRequest.builder(57000256L).storeRawResponse(true).build()).get();
    String actual = GSON.toJson(response);
    String expected = response.getRawResponse().getRaw();

    assertDiff(expected, actual);
  }

  @Test
  void locations_getTopPlayerLeagueSeasons() throws Exception {
    TopPlayerLeagueSeasonsResponse
        response =
        locationApi.getTopPlayerLeagueSeasons(TopPlayerLeagueSeasonsRequest.builder().storeRawResponse(true).build())
            .get();
    String actual = GSON.toJson(response);
    String expected = response.getRawResponse().getRaw();

    assertDiff(expected, actual);
  }

  @Test
  void locations_getTopPlayerLeagueSeason() throws Exception {
    TopPlayerLeagueSeasonResponse
        response =
        locationApi.getTopPlayerLeagueSeason(
            TopPlayerLeagueSeasonRequest.builder("2022-04").storeRawResponse(true).build()).get();
    String actual = GSON.toJson(response);
    String expected = response.getRawResponse().getRaw();

    assertDiff(expected, actual);
  }

  @Test
  void locations_getTopPlayerLeagueSeasonRankings() throws Exception {
    TopPlayerLeagueSeasonRankingsResponse
        response =
        locationApi.getTopPlayerLeagueSeasonRankings(
            TopPlayerLeagueSeasonRankingsRequest.builder("2022-04").storeRawResponse(true).build()).get();
    String actual = GSON.toJson(response);
    String expected = response.getRawResponse().getRaw();

    assertDiff(expected, actual);
  }

  @Test
  void challenges_findAll() throws Exception {
    ChallengesResponse
        response =
        challengeApi.findAll(ChallengesRequest.builder().storeRawResponse(true).build()).get();
    String actual = GSON.toJson(response)
        .replace(",\"amount\":0", "")
        .replace(",{\"amount\":0}", "")
        .replace(",{\"type\":null}", "")
        .replace(",\"type\":null", "");
    String expected = response.getRawResponse().getRaw()
        .replace(",{\"type\":null}", "")
        .replace("\"name\":null,", "");

    assertDiff(expected, actual);
  }

  @Test
  void globalTournaments_findAll() throws Exception {
    GlobalTournamentsResponse
        response = globalTournamentApi.findAll(GlobalTournamentsRequest.builder().storeRawResponse(true).build()).get();
    String actual = GSON.toJson(response)
        .replace(",\"amount\":0", "");
    String expected = response.getRawResponse().getRaw()
        .replace(",\"type\":null", "")
        .replace("\"name\":null,", "");

    assertDiff(expected, actual);
  }

}
